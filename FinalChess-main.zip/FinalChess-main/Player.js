


let Player = function(ident,name,wins,losses) {
	this.ident = ident;
	this.name = name;
	this.wins=wins;
	this.losses=losses;
}

module.exports = Player;
